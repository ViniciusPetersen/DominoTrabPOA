import java.io.File;
import java.io.FileNotFoundException;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Scanner;

public class  Domino {
    public static void main(String[] args) {
        // Nome do arquivo a ser lido
        String fileName = "casos/caso20.txt";

        // Arraylist para armazenar as peças de domino
        ArrayList<DominoPeca> dominoPecas = new ArrayList<>();

        try {
            // Criar um scanner para ler o arquivo
            Scanner scanner = new Scanner(new File(fileName));

            // Ler o número total de peças de domino
            int numPecas = scanner.nextInt();

            // Ler cada peça de domino e adicioná-la ao arraylist
            for (int i = 0; i < numPecas; i++) {
                int left = scanner.nextInt();
                int right = scanner.nextInt();
                DominoPeca peca = new DominoPeca(left, right);
                dominoPecas.add(peca);
            }

            // Fechar o scanner
            scanner.close();
        } catch (FileNotFoundException e) {
            System.out.println("Arquivo não encontrado: " + e.getMessage());
        }

        // Imprimir as peças de domino
        for (DominoPeca peca : dominoPecas) {
            System.out.println(peca);
        }
    }



    public int[] DominoCalculo(int arrayAtual[], int arrayInteiro[]){
         
        return arrayAtual;
    }
}