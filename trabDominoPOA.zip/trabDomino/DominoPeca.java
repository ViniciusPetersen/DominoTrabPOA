public class DominoPeca {
        int left;
        int right;

        public DominoPeca(int left, int right) {
            this.left = left;
            this.right = right;
        }

        @Override
        public String toString() {
            return "[" + left + "|" + right + "]";
        }

}